import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileEncryptDecrypt {
    private static final int SHIFT = 3; // Caesar cipher shift value

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Do you want to (E)ncrypt or (D)ecrypt a file?");
        String choice = scanner.nextLine().toUpperCase();

        System.out.println("Enter the file name or path:");
        String filePath = scanner.nextLine();

        System.out.println("Enter the output file name or path:");
        String outputFilePath = scanner.nextLine();

        if (choice.equals("E")) {
            processFile(filePath, outputFilePath, true);
            System.out.println("File encrypted successfully.");
        } else if (choice.equals("D")) {
            processFile(filePath, outputFilePath, false);
            System.out.println("File decrypted successfully.");
        } else {
            System.out.println("Invalid choice. Please choose 'E' for encryption or 'D' for decryption.");
        }

        scanner.close();
    }

    private static void processFile(String inputFilePath, String outputFilePath, boolean isEncrypt) {
        try {
            File inputFile = new File(inputFilePath);
            Scanner fileScanner = new Scanner(inputFile);
            StringBuilder fileContent = new StringBuilder();

            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                fileContent.append(line).append(System.lineSeparator());
            }

            String processedContent = isEncrypt ? encrypt(fileContent.toString()) : decrypt(fileContent.toString());

            FileWriter fileWriter = new FileWriter(outputFilePath);
            fileWriter.write(processedContent);
            fileWriter.close();

            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + inputFilePath);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + outputFilePath);
        }
    }

    private static String encrypt(String input) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : input.toCharArray()) {
            if (Character.isLetter(c)) {
                char shifted = (char) (c + SHIFT);
                if ((Character.isLowerCase(c) && shifted > 'z') || (Character.isUpperCase(c) && shifted > 'Z')) {
                    shifted -= 26;
                }
                encrypted.append(shifted);
            } else {
                encrypted.append(c);
            }
        }
        return encrypted.toString();
    }

    private static String decrypt(String input) {
        StringBuilder decrypted = new StringBuilder();
        for (char c : input.toCharArray()) {
            if (Character.isLetter(c)) {
                char shifted = (char) (c - SHIFT);
                if ((Character.isLowerCase(c) && shifted < 'a') || (Character.isUpperCase(c) && shifted < 'A')) {
                    shifted += 26;
                }
                decrypted.append(shifted);
            } else {
                decrypted.append(c);
            }
        }
        return decrypted.toString();
    }
}