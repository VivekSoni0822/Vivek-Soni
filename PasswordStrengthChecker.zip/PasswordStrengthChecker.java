import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordStrengthChecker {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a password to check its strength:");
        String password = scanner.nextLine();
        
        String strength = checkPasswordStrength(password);
        System.out.println("Password strength: " + strength);
    }

    public static String checkPasswordStrength(String password) {
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        boolean hasLength = password.length() >= 8;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(c)) {
                hasLowercase = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (isSpecialCharacter(c)) {
                hasSpecialChar = true;
            }
        }

        int strengthCount = 0;
        if (hasUppercase) strengthCount++;
        if (hasLowercase) strengthCount++;
        if (hasNumber) strengthCount++;
        if (hasSpecialChar) strengthCount++;
        if (hasLength) strengthCount++;

        if (strengthCount < 3) {
            return "Weak";
        } else if (strengthCount < 5) {
            return "Moderate";
        } else {
            return "Strong";
        }
    }

    private static boolean isSpecialCharacter(char c) {
        Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
        Matcher matcher = pattern.matcher(String.valueOf(c));
        return matcher.find();
    }
}